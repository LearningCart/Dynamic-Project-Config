#include <stdio.h>
#include "sysconfig.h"

#define	ENABLED	(1)

int main(int argc, char **argv)
{
#if (BUILD_CORE_COMP == ENABLED)
	printf("BUILD_CORE_COMP is defined\n");
#endif

#if (CREATE_DEBUG_BUILD == ENABLED)
	printf("CREATE_DEBUG_BUILD is defined\n");
#endif

#if (ENABLE_VM == ENABLED)
	printf("ENABLE_VM is defined\n");
#endif

#if (ENABLE_REMAPPING == ENABLED)
	printf("ENABLE_REMAPPING is defined\n");
#endif
#if (USE_LOCAL_ALLOC == ENABLED)
	printf("USE_LOCAL_ALLOC is defined\n");
#endif

	return 0;
}

