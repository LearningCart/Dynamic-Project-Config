/*
 * Jatin Gandhi
 * Reads the configuration file and generates sysconfig.h
 * Very useful for the projects which needs to selectively compile the
 * features from large set of features
 * Example config.txt
 * PREPROCESSOR_NAME=true  will translage to #define PREPROCESSOR_NAME (1)
 * PREPROCESSOR_NAME=false will translage to #define PREPROCESSOR_NAME (0)
 */

 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#define RELEASE_BUILD

#define null	NULL
#define SYSCONFIG	"sysconfig.h"
 
#ifdef RELEASE_BUILD
#define LOGGER(X)
#else
#define LOGGER(X)	printf X
#endif

/*
 * function:    GetCount
 * description: This function will count number  of times specific character appears in
 *              the buffer.
 */
static int GetCount(const unsigned char *buffer,unsigned char character)
{
	int count;

	count = 0;

	while(*buffer != 0)
	{
		if(*buffer == character ) count++;
		buffer++;
	}
	return count;
}

/*
 * function:    ConvertToArray
 * description: Converts the buffer into multiple line array.
 */
static char ** ConvertToArray(char *buffer, int *total_no_of_lines)
{
	int total_lines;
	char **array;
	int index;
	int i;

	total_lines = 0;

	if(null == buffer)
	{
		LOGGER(("%s:%s:%d->Please enter valid input params\n",__FILE__,__func__,__LINE__));
		return null;
	}

	total_lines = GetCount(buffer,'\n');
	*total_no_of_lines = total_lines;

	if(0 == total_lines)
	{
		LOGGER(("%s:%s:%d->Zero lines found\n",__FILE__,__func__,__LINE__));
		return null;
	}

	array = (char **) malloc(total_lines * sizeof(char *));
	if(null == array)
	{
		LOGGER(("%s:%s:%d->Failed to allocate memory\n",__FILE__,__func__,__LINE__));
		return null;
	}

	/* Start pointing to beginning of strings.. */
	index = 0;
	array[index] = buffer;

	while(0 != *buffer)
	{
		if('\n' == *buffer)
		{
			/* Replacing \n with null terminater and assigning fixes FIXME and TODO */
			*buffer = 0;
			index++;
			buffer++;
			array[index] = buffer;

		}else
		{
			buffer++;
		}
	}

	return array;	
}
/* TODO: FIXME: THIS WILL NOT TERMINATE INDIVIDUAL LINES... 
  so strlen + 1, memset and then copy until cr+lf  are found */

static char ** ReadAll(const char *filename, int *total_bytes,  unsigned char **buffer, int *totallines)
{

	/* Basic version of code BEGIN */
	FILE *fileptr;
	long filesize;
	char **array;
 
	if(null == filename || null == total_bytes || null == buffer | null == totallines)
	{
		LOGGER(("%s:%s:%d->Please enter valid input params\n",__FILE__,__func__,__LINE__));

		return null;
	}
        fileptr = null;
	fileptr = fopen(filename, "rb");

	if(NULL == fileptr)
	{
		LOGGER(("Faile dot open file %s\n",filename));
		return null;
	}
	
	fseek(fileptr, 0, SEEK_END);

	filesize = ftell(fileptr);

	fseek(fileptr, 0, SEEK_SET);

	*buffer = (unsigned char *)malloc(filesize + 1);

	memset(*buffer,0,filesize + 1);

	fread(*buffer, filesize, 1, fileptr);

	fclose(fileptr);

	(*buffer)[filesize] = 0;

	/* Basic version of code ends. */

	/* Lets convert buffer to array */
	array = null;
	array = ConvertToArray(*buffer, totallines);

	return array;
}


 void Usage(void)
 {
		printf("GenConfig <ConfigFile>\n");
		exit(0);
 }
 
#define SEPARATER_CHAR	'='
#define PROCESS_BUF_SIZE	255

void GenSysConnfig(char *line, FILE*  outfile)
{
	char *separator;
	char *optionval;
	static unsigned char ProcessBuff[PROCESS_BUF_SIZE];
	if((NULL == line) || (NULL == outfile))
	{
		return;
	}

	/* Check if we have only one '=' separator */
	if(GetCount(line,SEPARATER_CHAR) > 1)
	{
		/* FIXME: Not yet supported some circus required..,*/
	}
	else
	{
		/* Only one separator found */
		separator = strchr(line,SEPARATER_CHAR);
		if(NULL != separator)
		{
			/* Terminate at separator */
			*separator = '\0';

			memset(ProcessBuff,0,PROCESS_BUF_SIZE);

			strcat(ProcessBuff,"#define ");
			strcat(ProcessBuff,line); /* FIXME: To upper line*/

			separator ++;	
			if(strcasecmp(separator,"true") == 0)
			{
				optionval = "    (1)";
			}else
			{
				optionval = "    (0)";
			}
			strcat(ProcessBuff,optionval);
			strcat(ProcessBuff,"\n");

			fwrite(ProcessBuff, 1,strlen(ProcessBuff), outfile);
		}
	}


}

 int main(int argc, char **argv)
 {
	FILE *pfout;
	char **configline;
	int index;
        int total_bytes = 0, total_no_lines;
	unsigned char *buffer = null;

	if(argc < 2)
	{
		Usage();
	}
	
	pfout = fopen(SYSCONFIG,"wb+");
	if(NULL == pfout)
	{
		printf("Failed to open output file\n");
		exit(0);
	}
	
	
	/* Both file are ready, start the processing */

	configline = null;

	configline = ReadAll(argv[1], &total_bytes, &buffer,&total_no_lines);

	if(null != configline && total_no_lines > 0)
	{
		for(index = 0; index < total_no_lines; index++)
		{
			/* printf("Line: %s\n",configline[index]); */
			GenSysConnfig(configline[index], pfout);
		}
	}
	if(NULL != buffer)
	{
		free(buffer);
	}
	
	printf("Configuration file %s is generated\nPlease re-compile project using it\n",SYSCONFIG);
	return 0;
 }

